﻿using System;

namespace AULA2
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            
            const Int32 N = 50000;
            Console.WriteLine("GERANDO LISTA DE TAMANHO:" + N);
            Int32[] lista = new Int32[N];
           
           
            for (int i = 0; i < lista.Length; i++)
            {
                lista[i] = rnd.Next(0, 100);
            }
            Console.WriteLine("Lista Original");
            imprimirLista(lista);
            Console.WriteLine("**************************");
            Console.WriteLine("         ORDENANDO        ");
            Console.WriteLine("**************************");
            bubbleSort(lista);
            Console.WriteLine("Lista Ordenada");
            imprimirLista(lista);

         }
        public static void imprimirLista(Int32[] lista)
        {
            for (int i = 0; i < lista.Length; i++)
            {
                Console.Write(lista[i]+";");
            }
            Console.WriteLine("");
        }

         public static int buscaSequencial(Int32[] lista, Int32 x)
        {
            int i = 0;
            while (i < lista.Length && lista[i] != x) { i++; }

            if (i==lista.Length) { i = -1; }

            return i;
        }

        private static int buscaBinaria(int[] lista, int x)
        {
            int inicio = -1;
            int fim = lista.Length;
            int pos = 0; ;

            while (inicio < fim - 1)
            {
                pos = (int)((inicio + fim) / 2);
                Console.WriteLine(inicio + ":" + pos + ":" + fim);
                if (lista[pos] == x) { inicio = fim; }
                else if (lista[pos] < x) { inicio = pos; }
                else { fim = pos; }
            }

            if (lista[pos] != x) pos = -1;

            return pos;
        }

        public static void bubbleSort(Int32 [] lista)
        {
            int i, j;
            Int32 aux;
            int N = lista.Length;
            for (i = N - 1; i > 0; i--)
            {
                for (j = 0; j < i; j++)
                {
                    if (lista[j] > lista[j + 1])
                      {
                        aux = lista[j];
                        lista[j] = lista[j + 1];
                        lista[j + 1] = aux;
                      }
                    //imprimirLista(lista);
                }
                //Console.WriteLine("**************************************");
                //imprimirLista(lista);
                //Console.WriteLine("**************************************");
            }

        }
    }
}
