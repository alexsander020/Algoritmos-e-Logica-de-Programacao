﻿using System;

namespace RECURSIVIDADE
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Fatorial(4));
            //Exemplo1(5);
            //Exemplo2(10);
        }

        static int Fatorial(int N)
        {
            int fat=1;

            if (N > 1)
            {
                fat = N * Fatorial(N - 1); 
            }
            else
            {
                fat = 1;

            }

            return fat;
        }
        static void Exemplo2(int i)
        {
            for (int j = 0; j < i; j++)
           {
               Console.Write("*");
           }
           Console.WriteLine("");
            if (i > 1)
            {
                Exemplo2(i - 1);
               
            }
            for (int j = 0; j < i; j++)
            {
                Console.Write("*");
           }
            Console.WriteLine("");
        }

        static void Exemplo1(int i)
        {
            if (i > 0)
            {
                Exemplo1(i - 1);
            }
            Console.Write(i + "|");
        }
    }
}
