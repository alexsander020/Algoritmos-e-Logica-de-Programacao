﻿// See https://aka.ms/new-console-template for more information


Double NI = 7.4;
Double PI = 7.3;
Double PO = 6;

Double media =calcMedia(NI, PI, PO);
imprimirStatus(media);

Double calcMedia(Double NI, Double PI, Double PO)
{
    Double media = NI * 0.2 + PI * 0.3 + PO * 0.5;
    return media;
}

void imprimirStatus(Double media)
{
   if (media >= 6)
    {
        Console.WriteLine("APROVADO");
    }
    else
    {
        Console.WriteLine("REPROVADO");
    }
}
Double f(Double X)
{
    Double result = 2 * X;

    return result;
}


