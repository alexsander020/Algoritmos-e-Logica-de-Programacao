﻿
double calcVar(double preco1, double preco2)
{
    Double result = ((preco2/preco1)-1)*100;

    return result;
}





Double preco1 = 10;
Double preco2 = 5;

Double varia = calcVar(preco1, preco2);


Console.WriteLine("O Preço variou em " + varia + "%");