﻿Random rnd= new Random();

int[][] Matriz;
int nlin = rnd.Next(2,10);
int ncol = rnd.Next(2,10);

Matriz = new int[rnd.Next(2, 10)][];

for (int lin = 0; lin < Matriz.Length; lin++)
{
    ncol = rnd.Next(2, 10);
    Matriz[lin] = new int[ncol];
    for (int col = 0; col < Matriz[lin].Length; col++)
    {
        Matriz[lin][col] = rnd.Next(10, 100);
    }

}

int Maior = Matriz[0][0];
for (int lin = 0; lin < Matriz.Length; lin++)
{
    for (int col = 0; col < Matriz[lin].Length; col++)
    {
        Console.Write("[" + Matriz[lin][col] + "]");
        if (Matriz[lin][col] >Maior) { Maior = Matriz[lin][col]; }
    }
    Console.WriteLine();
}
Console.WriteLine("MAIOR NÚMERO DA MATRIZ:" + Maior);
