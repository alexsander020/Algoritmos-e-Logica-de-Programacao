﻿Random rnd = new Random();

int[][] Matriz;
int nlin = rnd.Next(2, 10);
int ncol = rnd.Next(2, 10);

Matriz = new int[rnd.Next(2, 10)][];

for (int lin = 0; lin < Matriz.Length; lin++)
{
    Matriz[lin] = new int[ncol];
    for (int col = 0; col < Matriz[lin].Length; col++)
    {
        Matriz[lin][col] = rnd.Next(1, 10);
    }

}

int num;
Console.Write("Entre com número que deseja contar:");
num=Convert.ToInt32(Console.ReadLine());
int contador=0;
for (int lin = 0; lin < Matriz.Length; lin++)
{
    for (int col = 0; col < Matriz[lin].Length; col++)
    {
        Console.Write("[" + Matriz[lin][col] + "]");
        if (Matriz[lin][col] == num)
        {
            contador++;
        }

    }
    Console.WriteLine();
}
Console.WriteLine(contador);


