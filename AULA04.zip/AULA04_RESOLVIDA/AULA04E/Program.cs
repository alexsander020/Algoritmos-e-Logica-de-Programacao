﻿int Fatorial(int N)
{
    int result = 1;
    string str = "1";
    for (int i = 2; i <= N; i++)
    {
        str=str + "*"+i.ToString();
        result = (result * i);
    }
    Console.WriteLine(str);
    return result;
}

Console.WriteLine(Fatorial(3));
Console.WriteLine(Fatorial(4));
Console.WriteLine(Fatorial(5));
Console.WriteLine(Fatorial(9));
Console.WriteLine(Fatorial(10));