﻿int f(int x)
{
    int result;
    result = 2*x;
    return result;

}

int r;

r = f(10);
Console.WriteLine(r);
Console.WriteLine(f(15));
Console.WriteLine(f(10+15));
Console.WriteLine(f(f(10)));
