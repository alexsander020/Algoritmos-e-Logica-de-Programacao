﻿
Double media(Double NI,Double PI,Double PO)
{
    Double result = NI*0.20 + PI*0.30 + PO*0.50;
    return result;
}

String status(Double media)
{
    String result;
    if (media < 2) 
    {
     result = "REPROVADO"; 
    }
    else if (media < 4)
    {
        result = "EXAME PRECISANDO DE 7.0 ";
    }
    else if (media < 6)
    {
        result = "EXAME PRECISANDO DE 6.0 ";
    }
    else
    {
        result = "APROVADO";

    }
    return result;
}

Double myNI, myPI, myPO;
Console.Write("ENTRE COM SUA NOTA DE NI:");
myNI = Convert.ToDouble(Console.ReadLine());
Console.Write("ENTRE COM SUA NOTA DE PI:");
myPI = Convert.ToDouble(Console.ReadLine());
Console.Write("ENTRE COM SUA NOTA DE PO:");
myPO = Convert.ToDouble(Console.ReadLine());

Double mf = media(myNI,myPI,myPO);
String sts = status(mf);

Console.WriteLine("Sua média    :"+mf);
Console.WriteLine("Sua situação :" + sts);