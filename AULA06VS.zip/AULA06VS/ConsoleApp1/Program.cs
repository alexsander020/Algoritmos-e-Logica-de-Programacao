﻿int BuscaSequencial(Int32 [] lista, Int32 elemento)
{
    int i = 0;
    //Enquanto NÃO VI TUDO E NÃO ACHEI
    while (i < lista.Length && lista[i] != elemento)
    { i++;}
    if (i == lista.Length)
    {i = -1; }
    return i;
}

int BuscaBinaria(Int32[] lista, Int32 elemento)
{
    int passos = 0;
    int inicio = -1;
    int fim=lista.Length;
    int pos = 0;

    while (inicio < (fim - 1))
    {
        passos++;
        pos = (int)((inicio + fim) / 2);
        if (lista[pos] == elemento) { inicio = fim; }
        else if (lista[pos] < elemento) { inicio = pos; }
        else { fim = pos; }
    }

    if (lista[pos]!=elemento) { pos=-1; }

    Console.WriteLine("PASSOS :" + passos);
    return pos;

}


    int N = 100000000;
Int32[] lista = new Int32[N];
Random rnd = new Random();
for (int i = 0; i < lista.Length; i++)
{
    lista[i] = i; //rnd.Next(0, 100000000);
}
/*for (int i = 0; i < lista.Length; i++)
{
    Console.WriteLine(lista[i]);
}*/
DateTime dt1 = DateTime.Now;
int num = 25000001;
Console.WriteLine("Pesquisa Sequencial Número "+num);
int pos = BuscaSequencial(lista,num);
DateTime dt2 = DateTime.Now;
Console.WriteLine(pos);
Console.WriteLine(dt1.Millisecond);
Console.WriteLine(dt2.Millisecond);

dt1 = DateTime.Now;
Console.WriteLine("Pesquisando Binaria Número " + num);
pos = BuscaBinaria(lista, num);
dt2 = DateTime.Now;
Console.WriteLine(pos);
Console.WriteLine(dt1.Millisecond);
Console.WriteLine(dt2.Millisecond);